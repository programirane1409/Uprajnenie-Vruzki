﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UprajnenieVruzki
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            pictureBox1.Hide();
            linkLabel2.Text = "Klikne tuk za pesen";
            linkLabel2.Links.Add(0,linkLabel2.Text.Length,"https://www.youtube.com/watch?v=E1jeW_eABIY");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            pictureBox1.Enabled= true;
            pictureBox1.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            pictureBox1.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToLongTimeString();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("https://weather-webcam.eu/ueb-kamera-ot-sofiya-okolovrasten-pat-pri-bul-balgariya/");
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string url = e.Link.LinkData as string;
            if(!string.IsNullOrEmpty(url) )
            {
                Process.Start(url);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Process.Start("https://weather-webcam.eu/ueb-kamera-ot-sofiya-okolovrasten-pat-pri-bul-balgariya/");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox2.Enabled = true;
            webBrowser2.Navigate("https://www.youtube.com/watch?v=E1jeW_eABIY");
            webBrowser1.Navigate("https://weather-webcam.eu/ueb-kamera-ot-sofiya-okolovrasten-pat-pri-bul-balgariya/");
        }
    }
}
